package com.dreamfactory.exam_controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
