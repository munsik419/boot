package com.dreamfactory.exam_controller.coffee;

public class Coffee {
    public Coffee(String korName, String engName, int price) {
    }
}
