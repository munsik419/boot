package com.dreamfactory.exam_controller.member;

public class  Member {
    public Member(String email, String name, String phone) {
    }
}
